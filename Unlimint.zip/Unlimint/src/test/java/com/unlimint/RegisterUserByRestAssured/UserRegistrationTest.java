package com.unlimint.RegisterUserByRestAssured;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class UserRegistrationTest {
	 @Test
	 public void RegisterUser() { 
	 	// Specify the base URL to the RESTful web service 
	 	RestAssured.baseURI = "https://randomuser.me/"; 
	 	// Get the RequestSpecification of the request to be sent to the server. 
	
	 }
	 }

}
